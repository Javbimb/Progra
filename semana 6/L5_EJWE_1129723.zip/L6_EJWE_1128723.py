print("Ejercicio 2")
print("Ingrese numero del 1 al 7")
v1 = input()
xnum = int(v1)
if xnum == 1:
   print("Dia Lunes")
elif xnum == 2:
   print("Dia Martes")
elif xnum == 3:
   print("Dia Miercoless")
elif xnum == 4:
   print("Dia Jueves")
elif xnum == 5:
   print("Dia Viernes")
elif xnum == 6:
   print("Dia Sabado")
elif xnum == 7:
   print("Dia Domingo")