'''variable1 = 21000
print (" comentario" )
print(variable1)
print(type(variable1), end="")

variable1 = "hola"
print(variable1)
print(type(variable1), end ="")

variable2=123.1 
print(variable2)
print(type (variable2))

variable3 = False
print(variable3)
print(type (variable3))'''

#print("hola mundo soy Javier Wolhers")
'''print("hola mundo")
print(" soy javier ")
#print(hace un salto de linea)
print("hola mundo", end="")
print(" soy javier ", end= "")'''
#print con end(escribe en la misma linea)

print ("Ingrese su nombre")
texto = input()
print(texto + " hola javier")